package com.dtcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDtccApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDtccApplication.class, args);
	}
}
