package com.cg.mobilebilling.client;
public class MainClass {
	public static void main(String[] args){
	}
}