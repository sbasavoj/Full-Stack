package com.cg.services;

public interface GreetingServices {
public void SayHello(String person);
public void SayBye(String person);
}
