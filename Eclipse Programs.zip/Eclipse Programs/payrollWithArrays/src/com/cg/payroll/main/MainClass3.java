package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;

public class MainClass3 {

	public static void main(String[] args) {
	

	}

}
