
public class MyThread extends Thread{

	public MyThread() {
		super();
	}
	public MyThread(String name) {
		super(name);
	}
	@Override
	public void run() {
		/*int i=0;
			if(this.getName().equals("thread-0"))
				while(i<50)
				System.out.print((i++)*2+" ");
			else if(this.getName().equals("thread-1"))
				while(i<50)
				System.out.print((i++)*2+1+" ");*/
			
	}
}
