package com.cg.banking.main;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Customer customer=new Customer(12345, 9491145306l, 326994125521l, "Vidya", "Basavoju", "vidya.abc@com", "qnksm", "12-22-11", new Address(12345, "Hyd", "TG", "India"), )		
	}

}
