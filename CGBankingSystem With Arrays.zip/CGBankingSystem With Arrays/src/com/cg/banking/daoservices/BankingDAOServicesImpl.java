package com.cg.banking.daoservices;
import java.util.Random;
import java.util.Arrays;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	private static Customer[] customerList=new Customer[10];
	private static int CUSTOMER_ID_GENERATOR=111;
	private static int CUSTOMER_IDX_COUNTER=0;	
	private static long ACCOUNT_ID_GENERATOR=10001l;
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_GENERATOR++);
		customer.setAccountCounter(0);
		if(CUSTOMER_IDX_COUNTER>.7*customerList.length){
			Customer[] tempArray = Arrays.copyOf(customerList, customerList.length+10);
			customerList=tempArray;
		}
		
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account){
		for(int i=0;i<customerList.length;i++)
			if(customerId==customerList[i].getCustomerId()){
				account.setAccountNo(ACCOUNT_ID_GENERATOR++);
				customerList[i].getAccounts()[customerList[i].getAccountCounter()]=account;
				customerList[i].setAccountCounter(customerList[i].getAccountCounter()+1);
				return account.getAccountNo();
				//return customerList[i].getAccounts()[customerList[i].getAccountCounter()-1].getAccountNo();
			}
		return 0;
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()==account.getAccountNo()){
				getCustomer(customerId).getAccounts()[i]=account;
				return true;
			}
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		Random n = new Random();
		int  pin = n.nextInt(9999) + 1001;
		account.setPinNumber(pin);
		updateAccount(customerId, account);
		return account.getPinNumber();

	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		Account account=getAccount(customerId,accountNo);
		if (account!=null){
			String concat=Long.toString(accountNo)+Integer.toString(account.getTransactionIdGenerator());
			account.getTransactions()[account.getTransactionCounter()].setTransactionId(Long.parseLong(concat));
			account.setTransactionCounter(account.getTransactionCounter()+1);
			account.setTransactionIdGenerator(account.getTransactionIdGenerator()+1);
			return true;
		}
		return false;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()){
				customerList[i]=null;
				for(int j=i;j<customerList.length&&(j+1)!=customerList.length;j++){
					customerList[j]=customerList[j+1];
					customerList[j+1]=null;
				}
				return true;
			}
		return false;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		Account account=getAccount(customerId, accountNo);
		if(account!=null){
			account=null;
			return true;
		}
		return false;
	}
	@Override
	public Customer getCustomer(int customerId) {
		for(Customer a:customerList)
			if(a!=null&&a.getCustomerId()==customerId)
				return a;	
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo)
				return getCustomer(customerId).getAccounts()[i];	
		return null;
	}
	@Override
	public Customer[] getCustomers() {
		return customerList;
	}
	@Override
	public Account[] getAccounts(int customerId) {
		return getCustomer(customerId).getAccounts();
	}
	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return getAccount(customerId, accountNo).getTransactions();
	}
}
