package com.cg;

import static org.junit.Assert.*;

import org.junit.Test;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testCucumber {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Given("^there is toothpaste on the brush$")
	public void there_is_toothpaste_on_the_brush() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^the mouth is open$")
	public void the_mouth_is_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^the back teeth are brushed$")
	public void the_back_teeth_are_brushed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^the front teeth are brushed$")
	public void the_front_teeth_are_brushed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the teeth look clean$")
	public void the_teeth_look_clean() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the mouth feels fresh$")
	public void the_mouth_feels_fresh() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the braces aren?t damaged$")
	public void the_braces_aren_t_damaged() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}




}
